# Tensura: Guia do Mestre — Mod Forge 1.12.2

Adaptação das regras centrais do Guia Mestre TenSura v10.9.

## Como compilar pelo celular (sem instalar nada)
1. Crie conta em github.com e um repositório novo (privado serve).
2. Envie TODO o conteúdo desta pasta (incluindo a pasta `.github`).
3. Aba **Actions** → "Build mod" → **Run workflow**.
4. Ao terminar, baixe o artefato `tensura-mod-jar` (contém o `.jar`).
5. Coloque o `.jar` na pasta `mods` do Forge 1.12.2 (14.23.5.2860) do seu launcher.

## Jogo
- `/tensura status` — ficha (raça, EP, rank, E, PC, pool).
- `/tensura race <raça>` — renasce como humano, slime, goblin, orc, ogro, lizardfolk, lobo, elfo ou vampiro.
- `/tensura unique <predator|sage|berserker|shadow>` — escolhe o núcleo da Skill Unique (5 Funções).
- Teclas: **Z** usa a função, **X** troca a função, **C** lança magia, **V** troca o Grau.
- Sem teclado (celular): `/tensura use`, `/tensura fn`, `/tensura cast`, `/tensura grade`.
- PC cresce matando criaturas (×0,75/0,5/0,35 por camada; ×1,5 com afinidade racial).
- Com PC ≥ 70 (Maturidade), clique direito na **Pedra de Evolução** para evoluir (chega a 10 PC, cura total).
- **Pergaminho de Nomeação**: clique direito numa criatura (custo/ganho pela razão de EP).
- Operadores: `/tensura pc <n>` e `/tensura give`.

## Fórmulas
EP = Piso × R^(PC/100) · E = (EP/1000)^0.4 · dano × E · vida = 20 × E · pool = max(INT,SAB)×5 + CON×2 + 10.
Funções custam FRAÇÃO do pool; magias Grau I–V custam 3/8/20/50/120 pontos.
