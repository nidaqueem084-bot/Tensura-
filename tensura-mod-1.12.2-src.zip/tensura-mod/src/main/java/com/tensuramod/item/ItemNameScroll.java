package com.tensuramod.item;

import com.tensuramod.Tensura;
import com.tensuramod.capability.TensuraCapability;
import com.tensuramod.capability.TensuraData;
import com.tensuramod.core.Scale;
import com.tensuramod.skill.SkillExecutor;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.EnumHand;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;

import java.util.UUID;

/** Nomeação: clique direito numa criatura. Custo e ganho por razão de EP (guia). */
public class ItemNameScroll extends Item {
    private static final UUID HP_ID = UUID.fromString("5b1b0c1e-2c7a-4f0a-9e11-7a1d2b3c4d5e");

    public ItemNameScroll() {
        setRegistryName(Tensura.MODID, "name_scroll");
        setUnlocalizedName(Tensura.MODID + ".name_scroll");
        setCreativeTab(CreativeTabs.MISC);
        setMaxStackSize(16);
    }

    /** EP estimado de uma criatura pela vida máxima (1 HP ~ 25 EP, piso 50). */
    public static double estimateEp(EntityLivingBase e) {
        return Math.max(50, e.getMaxHealth() * 25.0);
    }

    @Override
    public boolean itemInteractionForEntity(ItemStack st, EntityPlayer p, EntityLivingBase t, EnumHand h) {
        if (p.world.isRemote) return true;
        if (t instanceof EntityPlayer) return false;
        NBTTagCompound tag = t.getEntityData();
        if (tag.hasKey("tensura_owner")) {
            p.sendMessage(new TextComponentString(TextFormatting.RED + "Esta criatura já possui um nome."));
            return true;
        }
        TensuraData d = TensuraCapability.get(p);
        if (d == null) return false;
        double gap = d.ep() / estimateEp(t);
        double frac, gain;
        boolean collapse = false;
        if (gap < 2) {
            p.sendMessage(new TextComponentString(TextFormatting.RED + "Alvo forte demais para ser nomeado (razão de EP < 2×)."));
            return true;
        } else if (gap <= 5) {
            frac = 0.10; gain = 0.5;
        } else if (gap <= 15) {
            frac = 0.25; gain = 1.5;
        } else if (gap <= 50) {
            frac = 0.50; gain = 4.0;
        } else {
            frac = 0.75; gain = 5.0; collapse = true;
        }
        if (!SkillExecutor.spend(p, d, d.maxPool() * frac)) return true;
        if (collapse) {
            p.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, 24000, 1));
            p.addPotionEffect(new PotionEffect(MobEffects.WEAKNESS, 24000, 1));
        }
        String name = st.hasDisplayName() ? st.getDisplayName() : "Nomeado";
        tag.setString("tensura_owner", p.getUniqueID().toString());
        t.setCustomNameTag(name);
        double mult = Math.pow(1.0 + gain, 0.4);
        t.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).applyModifier(
                new AttributeModifier(HP_ID, "tensura_named", mult - 1.0, 2));
        t.setHealth(t.getMaxHealth());
        t.addPotionEffect(new PotionEffect(MobEffects.STRENGTH, Integer.MAX_VALUE, Math.min(4, (int) mult)));
        d.addPc(0.5);
        if (!p.capabilities.isCreativeMode) st.shrink(1);
        p.sendMessage(new TextComponentString(TextFormatting.AQUA + "Nomeação: razão " + (int) gap + "× | custo "
                + (int) (frac * 100) + "% do pool | EP +" + (int) (gain * 100) + "% | rank "
                + Scale.rank(estimateEp(t) * (1 + gain))));
        return true;
    }
}
