package com.tensuramod.item;

import com.tensuramod.Tensura;
import com.tensuramod.capability.TensuraCapability;
import com.tensuramod.capability.TensuraData;
import com.tensuramod.network.NetworkHandler;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;

/** Gatilho narrativo de evolução: exige Maturidade (PC >= 70). */
public class ItemEvolutionStone extends Item {
    public ItemEvolutionStone() {
        setRegistryName(Tensura.MODID, "evolution_stone");
        setUnlocalizedName(Tensura.MODID + ".evolution_stone");
        setCreativeTab(CreativeTabs.MISC);
        setMaxStackSize(16);
    }

    @Override
    public ActionResult<ItemStack> onItemRightClick(World w, EntityPlayer p, EnumHand h) {
        ItemStack st = p.getHeldItem(h);
        if (w.isRemote) return new ActionResult<>(EnumActionResult.SUCCESS, st);
        TensuraData d = TensuraCapability.get(p);
        if (d == null) return new ActionResult<>(EnumActionResult.FAIL, st);
        if (!d.race.hasNext(d.stage)) {
            p.sendMessage(new TextComponentString(TextFormatting.YELLOW + "Você já está no último degrau da sua linhagem."));
            return new ActionResult<>(EnumActionResult.FAIL, st);
        }
        if (!d.mature()) {
            p.sendMessage(new TextComponentString(TextFormatting.RED + "Sem Maturidade (PC 70+). PC atual: " + (int) d.pc));
            return new ActionResult<>(EnumActionResult.FAIL, st);
        }
        d.evolve();
        p.setHealth(p.getMaxHealth());
        if (!p.capabilities.isCreativeMode) st.shrink(1);
        p.sendMessage(new TextComponentString(TextFormatting.GOLD + "EVOLUÇÃO! Agora você é " + d.stageInfo().name + " (EP " + (long) d.ep() + ")"));
        NetworkHandler.sync((EntityPlayerMP) p);
        return new ActionResult<>(EnumActionResult.SUCCESS, st);
    }
}
