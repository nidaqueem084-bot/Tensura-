package com.tensuramod.item;

import com.tensuramod.Tensura;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.item.Item;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@Mod.EventBusSubscriber(modid = Tensura.MODID)
public class ModItems {
    public static final Item NAME_SCROLL = new ItemNameScroll();
    public static final Item EVOLUTION_STONE = new ItemEvolutionStone();

    @SubscribeEvent
    public static void register(RegistryEvent.Register<Item> e) {
        e.getRegistry().registerAll(NAME_SCROLL, EVOLUTION_STONE);
    }

    @SubscribeEvent
    @SideOnly(Side.CLIENT)
    public static void models(ModelRegistryEvent e) {
        for (Item i : new Item[]{NAME_SCROLL, EVOLUTION_STONE}) {
            ModelLoader.setCustomModelResourceLocation(i, 0, new ModelResourceLocation(i.getRegistryName(), "inventory"));
        }
    }
}
