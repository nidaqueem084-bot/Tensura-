package com.tensuramod.network;

import com.tensuramod.capability.TensuraCapability;
import com.tensuramod.capability.TensuraData;
import com.tensuramod.skill.SkillExecutor;
import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

/** Cliente -> servidor: ação de tecla. 0 usar função, 1 próxima função, 2 lançar magia, 3 próximo grau. */
public class PacketAction implements IMessage {
    public int action;

    public PacketAction() {}

    public PacketAction(int a) {
        action = a;
    }

    @Override
    public void fromBytes(ByteBuf buf) {
        action = buf.readByte();
    }

    @Override
    public void toBytes(ByteBuf buf) {
        buf.writeByte(action);
    }

    public static class Handler implements IMessageHandler<PacketAction, IMessage> {
        @Override
        public IMessage onMessage(PacketAction m, MessageContext ctx) {
            final EntityPlayerMP p = ctx.getServerHandler().player;
            final int a = m.action;
            p.getServerWorld().addScheduledTask(() -> {
                TensuraData d = TensuraCapability.get(p);
                if (d == null) return;
                switch (a) {
                    case 0: SkillExecutor.useFunction(p, d); break;
                    case 1: d.selFunction = d.selFunction.next(); break;
                    case 2: SkillExecutor.cast(p, d); break;
                    case 3: d.selSpell = d.selSpell.next(); break;
                    default: break;
                }
                NetworkHandler.sync(p);
            });
            return null;
        }
    }
}
