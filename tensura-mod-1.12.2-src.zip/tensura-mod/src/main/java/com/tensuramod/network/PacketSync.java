package com.tensuramod.network;

import com.tensuramod.client.ClientHooks;
import io.netty.buffer.ByteBuf;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraftforge.fml.common.network.ByteBufUtils;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

/** Servidor -> cliente: dados do jogador. */
public class PacketSync implements IMessage {
    public NBTTagCompound tag = new NBTTagCompound();

    public PacketSync() {}

    public PacketSync(NBTTagCompound t) {
        tag = t;
    }

    @Override
    public void fromBytes(ByteBuf buf) {
        tag = ByteBufUtils.readTag(buf);
    }

    @Override
    public void toBytes(ByteBuf buf) {
        ByteBufUtils.writeTag(buf, tag);
    }

    public static class Handler implements IMessageHandler<PacketSync, IMessage> {
        @Override
        public IMessage onMessage(PacketSync m, MessageContext ctx) {
            ClientHooks.sync(m.tag);
            return null;
        }
    }
}
