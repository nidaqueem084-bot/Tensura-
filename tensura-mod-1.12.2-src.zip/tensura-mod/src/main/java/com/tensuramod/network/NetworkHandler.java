package com.tensuramod.network;

import com.tensuramod.Tensura;
import com.tensuramod.capability.TensuraCapability;
import com.tensuramod.capability.TensuraData;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import net.minecraftforge.fml.relauncher.Side;

public class NetworkHandler {
    public static final SimpleNetworkWrapper CH = NetworkRegistry.INSTANCE.newSimpleChannel(Tensura.MODID);

    public static void init() {
        CH.registerMessage(PacketSync.Handler.class, PacketSync.class, 0, Side.CLIENT);
        CH.registerMessage(PacketAction.Handler.class, PacketAction.class, 1, Side.SERVER);
    }

    public static void sync(EntityPlayerMP p) {
        TensuraData d = TensuraCapability.get(p);
        if (d != null) CH.sendTo(new PacketSync(d.write()), p);
    }
}
