package com.tensuramod;

import com.tensuramod.network.NetworkHandler;
import com.tensuramod.proxy.CommonProxy;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;

@Mod(modid = Tensura.MODID, name = Tensura.NAME, version = "1.0.0", acceptedMinecraftVersions = "[1.12.2]")
public class Tensura {
    public static final String MODID = "tensura";
    public static final String NAME = "Tensura: Guia do Mestre";

    @Mod.Instance(MODID)
    public static Tensura instance;

    @SidedProxy(clientSide = "com.tensuramod.proxy.ClientProxy", serverSide = "com.tensuramod.proxy.CommonProxy")
    public static CommonProxy proxy;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent e) {
        NetworkHandler.init();
        proxy.preInit(e);
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent e) {
        proxy.init(e);
    }

    @Mod.EventHandler
    public void serverStarting(FMLServerStartingEvent e) {
        e.registerServerCommand(new com.tensuramod.command.CommandTensura());
    }
}
