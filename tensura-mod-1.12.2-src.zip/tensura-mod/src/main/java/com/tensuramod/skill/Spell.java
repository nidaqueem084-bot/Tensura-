package com.tensuramod.skill;

/** Magia por Grau: custo ABSOLUTO em pontos de pool. */
public enum Spell {
    I(1, 3, 1, 6),
    II(2, 8, 1, 8),
    III(3, 20, 1, 10),
    IV(4, 50, 1, 12),
    V(5, 120, 2, 12);

    public final int grade, cost, diceCount, diceSides;

    Spell(int g, int c, int n, int s) {
        grade = g;
        cost = c;
        diceCount = n;
        diceSides = s;
    }

    public Spell next() {
        return values()[(ordinal() + 1) % values().length];
    }

    public double roll(java.util.Random r) {
        int t = 0;
        for (int i = 0; i < diceCount; i++) t += r.nextInt(diceSides) + 1;
        return t;
    }
}
