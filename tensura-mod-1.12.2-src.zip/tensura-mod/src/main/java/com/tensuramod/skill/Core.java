package com.tensuramod.skill;

/** Núcleo da Skill Unique: define o "sabor" das 5 Funções. */
public enum Core {
    PREDATOR("Predador", "Devora: golpes curam parte do dano causado"),
    SAGE("Grande Sábio", "Análise: passos anulam queda, percepção maior"),
    BERSERKER("Berserker", "Fúria: golpes causam +50% de dano"),
    SHADOW("Sombra", "Furtividade: passo mais longo e invisibilidade breve");

    public final String display, desc;

    Core(String d, String desc) {
        this.display = d;
        this.desc = desc;
    }

    public static Core byName(String s) {
        for (Core c : values()) {
            if (c.name().equalsIgnoreCase(s) || c.display.equalsIgnoreCase(s)) return c;
        }
        return null;
    }
}
