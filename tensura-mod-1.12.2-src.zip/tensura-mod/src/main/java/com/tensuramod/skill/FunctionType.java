package com.tensuramod.skill;

/** As 5 Funções da Skill Unique. Custo = FRAÇÃO do pool máximo. */
public enum FunctionType {
    STRIKE("Golpe", 0.05),
    GUARD("Escudo", 0.08),
    STEP("Passo", 0.03),
    SENSE("Percepção", 0.02),
    ANCHOR("Âncora (Utilidade)", 0.10);

    public final String display;
    public final double fraction;

    FunctionType(String d, double f) {
        this.display = d;
        this.fraction = f;
    }

    public FunctionType next() {
        return values()[(ordinal() + 1) % values().length];
    }
}
