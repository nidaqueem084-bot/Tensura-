package com.tensuramod.skill;

import com.tensuramod.capability.TensuraData;
import com.tensuramod.core.Scale;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.MobEffects;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.WorldServer;

import java.util.List;

public final class SkillExecutor {
    private SkillExecutor() {}

    public static void msg(EntityPlayer p, String s) {
        p.sendStatusMessage(new TextComponentString(s), true);
    }

    /** Gasta pool; retorna false se insuficiente. Pool em 0 = colapso. */
    public static boolean spend(EntityPlayer p, TensuraData d, double cost) {
        if (d.pool < cost) {
            msg(p, TextFormatting.RED + "Magicules insuficientes!");
            return false;
        }
        d.pool -= cost;
        if (d.pool <= 0.0001) {
            d.pool = 0;
            collapse(p);
        }
        return true;
    }

    public static void collapse(EntityPlayer p) {
        p.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, 600, 2));
        p.addPotionEffect(new PotionEffect(MobEffects.WEAKNESS, 600, 2));
        p.addPotionEffect(new PotionEffect(MobEffects.MINING_FATIGUE, 600, 1));
        msg(p, TextFormatting.DARK_RED + "Colapso de magicules!");
    }

    public static EntityLivingBase target(EntityPlayer p, double range) {
        Vec3d eye = p.getPositionEyes(1f);
        Vec3d look = p.getLookVec();
        EntityLivingBase best = null;
        double bd = range * range;
        AxisAlignedBB box = p.getEntityBoundingBox().expand(look.x * range, look.y * range, look.z * range).grow(1.5);
        for (Entity e : p.world.getEntitiesWithinAABBExcludingEntity(p, box)) {
            if (!(e instanceof EntityLivingBase) || !e.canBeCollidedWith()) continue;
            Vec3d to = new Vec3d(e.posX - eye.x, e.posY + e.height / 2 - eye.y, e.posZ - eye.z);
            double dist = to.lengthSquared();
            if (dist > bd) continue;
            if (to.normalize().dotProduct(look) < 0.93) continue;
            bd = dist;
            best = (EntityLivingBase) e;
        }
        return best;
    }

    private static void particles(EntityPlayer p, EnumParticleTypes t, double x, double y, double z, int n) {
        if (p.world instanceof WorldServer) ((WorldServer) p.world).spawnParticle(t, x, y, z, n, 0.4, 0.4, 0.4, 0.05);
    }

    public static void useFunction(EntityPlayerMP p, TensuraData d) {
        if (d.core == null) {
            msg(p, TextFormatting.RED + "Sem Skill Unique. Use /tensura unique <nucleo>.");
            return;
        }
        FunctionType f = d.selFunction;
        double e = d.e();
        if (!spend(p, d, d.maxPool() * f.fraction)) return;
        d.addPc(0.02);
        switch (f) {
            case STRIKE: {
                EntityLivingBase t = target(p, 6);
                if (t == null) {
                    msg(p, "Nenhum alvo.");
                    break;
                }
                double dmg = (p.getRNG().nextInt(6) + 1 + Scale.mod(d.attr())) * e;
                if (d.core == Core.BERSERKER) dmg *= 1.5;
                t.attackEntityFrom(DamageSource.causePlayerDamage(p).setMagicDamage(), (float) dmg);
                if (d.core == Core.PREDATOR) p.heal((float) (dmg * 0.2));
                particles(p, EnumParticleTypes.CRIT_MAGIC, t.posX, t.posY + 1, t.posZ, 20);
                break;
            }
            case GUARD: {
                int amp = (int) Math.min(4, Math.pow(e, 0.3) - 1);
                p.addPotionEffect(new PotionEffect(MobEffects.RESISTANCE, 200, Math.max(0, amp)));
                p.addPotionEffect(new PotionEffect(MobEffects.ABSORPTION, 200, Math.max(0, amp)));
                particles(p, EnumParticleTypes.VILLAGER_HAPPY, p.posX, p.posY + 1, p.posZ, 15);
                break;
            }
            case STEP: {
                double v = d.core == Core.SHADOW ? 2.2 : 1.5;
                Vec3d l = p.getLookVec();
                p.motionX = l.x * v;
                p.motionY = Math.max(0.25, l.y * v * 0.6);
                p.motionZ = l.z * v;
                p.velocityChanged = true;
                p.fallDistance = 0;
                                if (d.core == Core.SHADOW) p.addPotionEffect(new PotionEffect(MobEffects.INVISIBILITY, 80, 0));
                break;
            }
            case SENSE: {
                double r = d.core == Core.SAGE ? 48 : 32;
                List<EntityLivingBase> l = p.world.getEntitiesWithinAABB(EntityLivingBase.class, p.getEntityBoundingBox().grow(r));
                for (EntityLivingBase x : l) if (x != p) x.addPotionEffect(new PotionEffect(MobEffects.GLOWING, 200, 0));
                p.addPotionEffect(new PotionEffect(MobEffects.NIGHT_VISION, 400, 0));
                msg(p, "Percepção: " + (l.size() - 1) + " presença(s).");
                break;
            }
            case ANCHOR: {
                p.heal((float) (p.getMaxHealth() * 0.3));
                p.clearActivePotions();
                p.getFoodStats().addStats(6, 0.5f);
                particles(p, EnumParticleTypes.HEART, p.posX, p.posY + 1.5, p.posZ, 8);
                break;
            }
        }
    }

    public static void cast(EntityPlayerMP p, TensuraData d) {
        Spell s = d.selSpell;
        if (!spend(p, d, s.cost)) return;
        d.addPc(0.01 * s.grade);
        EntityLivingBase t = target(p, 24);
        double dmg = (s.roll(p.getRNG()) + Scale.mod(d.attr())) * d.e();
        if (t == null) {
            msg(p, "Magia Grau " + s.name() + " sem alvo.");
            return;
        }
        t.attackEntityFrom(DamageSource.causePlayerDamage(p).setMagicDamage(), (float) dmg);
        if (s.grade >= 2) t.setFire(2 + s.grade);
        particles(p, EnumParticleTypes.FLAME, t.posX, t.posY + 1, t.posZ, 10 * s.grade);
        if (s.grade >= 4) p.world.createExplosion(p, t.posX, t.posY, t.posZ, s.grade - 2, false);
    }
}
