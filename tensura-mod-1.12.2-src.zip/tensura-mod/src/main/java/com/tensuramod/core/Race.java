package com.tensuramod.core;

/** Raças com degraus (piso, teto). Camada: 0 material, 1 demi-espiritual, 2 espiritual, 3 espiritual topo. */
public enum Race {
    HUMAN("Humano", 0, new Stage("Humano", 1000, 5000), new Stage("Iluminado", 5000, 80000)),
    SLIME("Slime", 2, new Stage("Slime", 300, 2100), new Stage("Slime Superior", 2100, 14600),
            new Stage("Slime Maior", 14600, 101000), new Stage("Demon Slime", 101000, 700000)),
    GOBLIN("Goblin", 0, new Stage("Goblin", 50, 300), new Stage("Hobgoblin", 300, 1000)),
    ORC("Orc", 0, new Stage("Orc", 300, 1000), new Stage("High Orc", 1000, 10000),
            new Stage("Orc Lord", 10000, 200000)),
    OGRE("Ogro", 0, new Stage("Ogro", 1500, 7000), new Stage("Kijin", 7000, 10000),
            new Stage("Oni", 10000, 400000)),
    LIZARDFOLK("Homem-Lagarto", 0, new Stage("Lizardfolk", 1500, 6000), new Stage("Dragonewt", 6000, 40000),
            new Stage("True Dragonewt", 40000, 400000)),
    WOLF("Lobo", 0, new Stage("Lobo", 500, 2000), new Stage("Tempest Wolf", 2000, 10000),
            new Stage("Star Wolf", 10000, 100000)),
    ELF("Elfo", 1, new Stage("Elfo Comum", 1000, 8000), new Stage("Sangue Antigo", 8000, 60000),
            new Stage("Elfo Puro", 60000, 150000), new Stage("Fada", 150000, 300000)),
    VAMPIRE("Vampiro", 1, new Stage("Vampiro", 5000, 12500), new Stage("Surmounter", 12500, 150000),
            new Stage("Noble", 150000, 300000));

    public final String display;
    public final int layer;
    public final Stage[] stages;

    Race(String display, int layer, Stage... stages) {
        this.display = display;
        this.layer = layer;
        this.stages = stages;
    }

    public Stage stage(int i) {
        return stages[Math.max(0, Math.min(stages.length - 1, i))];
    }

    public boolean hasNext(int i) {
        return i + 1 < stages.length;
    }

    public static Race byName(String s) {
        for (Race r : values()) {
            if (r.name().equalsIgnoreCase(s) || r.display.equalsIgnoreCase(s)) return r;
        }
        return null;
    }

    public static final class Stage {
        public final String name;
        public final double piso, teto;

        Stage(String name, double piso, double teto) {
            this.name = name;
            this.piso = piso;
            this.teto = teto;
        }
    }
}
