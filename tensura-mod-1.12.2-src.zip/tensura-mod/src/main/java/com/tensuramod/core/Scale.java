package com.tensuramod.core;

/** Fórmulas do guia: EP, escala E, HP, dano, pool de magicules, ranks. */
public final class Scale {
    private Scale() {}

    /** EP = Piso × R^(PC/100), com R = (Teto/Piso). PC limitado a 0..95. */
    public static double ep(double piso, double teto, double pc) {
        pc = Math.max(0, Math.min(95, pc));
        double r = teto / piso;
        return piso * Math.pow(r, pc / 100.0);
    }

    /** E = (EP/1000)^0.4, mínimo 1. */
    public static double e(double ep) {
        return Math.max(1.0, Math.pow(ep / 1000.0, 0.4));
    }

    /** Modificador de atributo = (attr - 10)/2. */
    public static double mod(int attr) {
        return (attr - 10) / 2.0;
    }

    /** HP = (CON×5 + FOR×2) × E. */
    public static double hp(int con, int forc, double e) {
        return (con * 5 + forc * 2) * e;
    }

    /** Pool de magicules = max(INT,SAB)×5 + CON×2 + 10. */
    public static double pool(int intel, int sab, int con) {
        return Math.max(intel, sab) * 5 + con * 2 + 10;
    }

    /** Multiplicador de evolução = (Piso/PisoRef)^0.4 (PisoRef >= 1000). */
    public static double evoMult(double piso, double pisoRef) {
        return Math.pow(piso / Math.max(1000.0, pisoRef), 0.4);
    }

    public static String rank(double ep) {
        if (ep < 1000) return "E";
        if (ep < 3000) return "D";
        if (ep < 6000) return "C";
        if (ep < 8000) return "B";
        if (ep < 9000) return "B+";
        if (ep < 10000) return "A-";
        if (ep < 100000) return "A";
        if (ep < 400000) return "Special-A";
        if (ep < 800000) return "S";
        if (ep < 1000000) return "Special-S";
        return "Million";
    }

    public static double layerFactor(int layer) {
        switch (layer) {
            case 1: return 0.75;
            case 2: return 0.5;
            case 3: return 0.35;
            default: return 1.0;
        }
    }
}
