package com.tensuramod.proxy;

import com.tensuramod.capability.TensuraCapability;
import com.tensuramod.event.CommonEvents;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

public class CommonProxy {
    public void preInit(FMLPreInitializationEvent e) {
        TensuraCapability.register();
        MinecraftForge.EVENT_BUS.register(new CommonEvents());
    }

    public void init(FMLInitializationEvent e) {
    }
}
