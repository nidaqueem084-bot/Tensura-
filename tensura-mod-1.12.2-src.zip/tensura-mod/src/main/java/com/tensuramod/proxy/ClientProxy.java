package com.tensuramod.proxy;

import com.tensuramod.client.ClientEvents;
import com.tensuramod.client.Keys;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

public class ClientProxy extends CommonProxy {
    @Override
    public void preInit(FMLPreInitializationEvent e) {
        super.preInit(e);
    }

    @Override
    public void init(FMLInitializationEvent e) {
        super.init(e);
        Keys.register();
        MinecraftForge.EVENT_BUS.register(new ClientEvents());
    }
}
