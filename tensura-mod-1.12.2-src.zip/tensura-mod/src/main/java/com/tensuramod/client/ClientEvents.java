package com.tensuramod.client;

import com.tensuramod.capability.TensuraCapability;
import com.tensuramod.capability.TensuraData;
import com.tensuramod.core.Scale;
import com.tensuramod.network.NetworkHandler;
import com.tensuramod.network.PacketAction;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;

public class ClientEvents {
    @SubscribeEvent
    public void key(InputEvent.KeyInputEvent e) {
        if (Keys.USE.isPressed()) NetworkHandler.CH.sendToServer(new PacketAction(0));
        if (Keys.NEXT_FN.isPressed()) NetworkHandler.CH.sendToServer(new PacketAction(1));
        if (Keys.CAST.isPressed()) NetworkHandler.CH.sendToServer(new PacketAction(2));
        if (Keys.GRADE.isPressed()) NetworkHandler.CH.sendToServer(new PacketAction(3));
    }

    @SubscribeEvent
    public void hud(RenderGameOverlayEvent.Post e) {
        if (e.getType() != RenderGameOverlayEvent.ElementType.ALL) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.player == null || mc.gameSettings.showDebugInfo) return;
        TensuraData d = TensuraCapability.get(mc.player);
        if (d == null) return;
        FontRenderer f = mc.fontRenderer;
        int x = 6, y = 6;
        double ep = d.ep();
        f.drawStringWithShadow("§6" + d.race.display + " §f" + d.stageInfo().name
                + " §7[" + Scale.rank(ep) + "]", x, y, 0xFFFFFF);
        f.drawStringWithShadow("EP " + (long) ep + "  E x" + String.format("%.2f", d.e()), x, y + 10, 0xFFFFFF);
        f.drawStringWithShadow("PC " + (int) d.pc + "/95" + (d.mature() ? " §a(Maturo)" : ""), x, y + 20, 0xFFFFFF);
        int w = 100;
        double max = Math.max(1, d.maxPool());
        int fill = (int) (w * Math.max(0, Math.min(1, d.pool / max)));
        Gui.drawRect(x - 1, y + 30, x + w + 1, y + 40, 0xFF000000);
        Gui.drawRect(x, y + 31, x + fill, y + 39, 0xFF3B8CFF);
        f.drawStringWithShadow((long) d.pool + "/" + (long) max, x + 3, y + 31, 0xFFFFFF);
        f.drawStringWithShadow("§dFn: " + d.selFunction.display + "  §bMagia: " + d.selSpell.name(), x, y + 44, 0xFFFFFF);
    }
}
