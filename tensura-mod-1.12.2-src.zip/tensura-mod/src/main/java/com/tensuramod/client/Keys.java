package com.tensuramod.client;

import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import org.lwjgl.input.Keyboard;

public class Keys {
    public static final KeyBinding USE = new KeyBinding("key.tensura.use", Keyboard.KEY_Z, "key.categories.tensura");
    public static final KeyBinding NEXT_FN = new KeyBinding("key.tensura.fn", Keyboard.KEY_X, "key.categories.tensura");
    public static final KeyBinding CAST = new KeyBinding("key.tensura.cast", Keyboard.KEY_C, "key.categories.tensura");
    public static final KeyBinding GRADE = new KeyBinding("key.tensura.grade", Keyboard.KEY_V, "key.categories.tensura");

    public static void register() {
        ClientRegistry.registerKeyBinding(USE);
        ClientRegistry.registerKeyBinding(NEXT_FN);
        ClientRegistry.registerKeyBinding(CAST);
        ClientRegistry.registerKeyBinding(GRADE);
    }
}
