package com.tensuramod.client;

import com.tensuramod.capability.TensuraCapability;
import com.tensuramod.capability.TensuraData;
import net.minecraft.client.Minecraft;
import net.minecraft.nbt.NBTTagCompound;

public class ClientHooks {
    public static void sync(final NBTTagCompound tag) {
        final Minecraft mc = Minecraft.getMinecraft();
        mc.addScheduledTask(() -> {
            if (mc.player == null) return;
            TensuraData d = TensuraCapability.get(mc.player);
            if (d != null) d.read(tag);
        });
    }
}
