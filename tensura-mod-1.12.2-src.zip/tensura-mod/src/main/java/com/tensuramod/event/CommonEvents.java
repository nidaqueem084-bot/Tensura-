package com.tensuramod.event;

import com.tensuramod.Tensura;
import com.tensuramod.capability.TensuraCapability;
import com.tensuramod.capability.TensuraData;
import com.tensuramod.core.Race;
import com.tensuramod.network.NetworkHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.MobEffects;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.living.LivingSetAttackTargetEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent.PlayerChangedDimensionEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent.PlayerLoggedInEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent.PlayerRespawnEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

import java.util.UUID;

public class CommonEvents {
    private static final UUID HP_ID = UUID.fromString("0a6c3a6e-6f0e-4a0e-8d55-3c2f1b9e7a10");

    @SubscribeEvent
    public void attach(AttachCapabilitiesEvent<Entity> e) {
        if (e.getObject() instanceof EntityPlayer) {
            e.addCapability(new ResourceLocation(Tensura.MODID, "data"), new TensuraCapability.Provider());
        }
    }

    @SubscribeEvent
    public void clone(PlayerEvent.Clone e) {
        TensuraData o = TensuraCapability.get(e.getOriginal());
        TensuraData n = TensuraCapability.get(e.getEntityPlayer());
        if (o != null && n != null) {
            n.read(o.write());
            if (e.isWasDeath()) n.pool = n.maxPool();
        }
    }

    @SubscribeEvent
    public void login(PlayerLoggedInEvent e) {
        sync(e.player);
    }

    @SubscribeEvent
    public void respawn(PlayerRespawnEvent e) {
        sync(e.player);
    }

    @SubscribeEvent
    public void dim(PlayerChangedDimensionEvent e) {
        sync(e.player);
    }

    private void sync(EntityPlayer p) {
        if (p instanceof EntityPlayerMP) NetworkHandler.sync((EntityPlayerMP) p);
    }

    private void passive(EntityPlayer p, Potion pot, int amp) {
        p.addPotionEffect(new PotionEffect(pot, 140, amp, true, false));
    }

    @SubscribeEvent
    public void tick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.player.world.isRemote) return;
        EntityPlayer p = e.player;
        if (p.ticksExisted % 20 != 0) return;
        TensuraData d = TensuraCapability.get(p);
        if (d == null) return;
        double max = d.maxPool();
        if (d.pool < 0) d.pool = max;
        d.pool = Math.min(max, d.pool + max * 0.01);

        double target = Math.min(1000, 20.0 * d.e() - 20.0);
        IAttributeInstance hp = p.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH);
        AttributeModifier old = hp.getModifier(HP_ID);
        if (old == null || Math.abs(old.getAmount() - target) > 0.5) {
            if (old != null) hp.removeModifier(HP_ID);
            if (target > 0) hp.applyModifier(new AttributeModifier(HP_ID, "tensura_hp", target, 0));
        }

        switch (d.race) {
            case SLIME: passive(p, MobEffects.WATER_BREATHING, 0); break;
            case GOBLIN: passive(p, MobEffects.SPEED, 0); break;
            case ORC: passive(p, MobEffects.RESISTANCE, 0); break;
            case OGRE: passive(p, MobEffects.STRENGTH, 0); break;
            case LIZARDFOLK: passive(p, MobEffects.WATER_BREATHING, 0); break;
            case WOLF: passive(p, MobEffects.SPEED, 1); passive(p, MobEffects.NIGHT_VISION, 0); break;
            case ELF: passive(p, MobEffects.HASTE, 0); break;
            case VAMPIRE: passive(p, MobEffects.NIGHT_VISION, 0); passive(p, MobEffects.STRENGTH, 0); break;
            default: break;
        }
        sync(p);
    }

    @SubscribeEvent
    public void fall(LivingFallEvent e) {
        if (e.getEntityLiving() instanceof EntityPlayer) {
            TensuraData d = TensuraCapability.get((EntityPlayer) e.getEntityLiving());
            if (d != null && d.race == Race.SLIME) e.setDistance(0);
        }
    }

    @SubscribeEvent
    public void hurt(LivingHurtEvent e) {
        Entity src = e.getSource().getTrueSource();
        if (src instanceof EntityPlayer && !e.getSource().isMagicDamage()) {
            TensuraData d = TensuraCapability.get((EntityPlayer) src);
            if (d != null) e.setAmount((float) (e.getAmount() * d.e()));
        }
    }

    @SubscribeEvent
    public void death(LivingDeathEvent e) {
        Entity src = e.getSource().getTrueSource();
        if (!(src instanceof EntityPlayer) || src.world.isRemote) return;
        EntityPlayer p = (EntityPlayer) src;
        TensuraData d = TensuraCapability.get(p);
        if (d == null) return;
        EntityLivingBase v = e.getEntityLiving();
        double ratio = Math.max(0.1, Math.min(3.0, v.getMaxHealth() / Math.max(1.0, p.getMaxHealth())));
        double gain = 0.8 * ratio * com.tensuramod.core.Scale.layerFactor(d.race.layer);
        boolean aff = false;
        switch (d.race) {
            case ORC: case GOBLIN: case OGRE: case LIZARDFOLK: aff = v instanceof EntityMob; break;
            case WOLF: aff = v instanceof EntityAnimal; break;
            case SLIME: aff = d.core == com.tensuramod.skill.Core.PREDATOR; break;
            default: break;
        }
        if (aff) gain *= 1.5;
        d.addPc(gain);
    }

    @SubscribeEvent
    public void target(LivingSetAttackTargetEvent e) {
        if (!(e.getEntityLiving() instanceof EntityLiving) || !(e.getTarget() instanceof EntityPlayer)) return;
        String owner = e.getEntityLiving().getEntityData().getString("tensura_owner");
        if (owner.equals(e.getTarget().getUniqueID().toString())) {
            ((EntityLiving) e.getEntityLiving()).setAttackTarget(null);
        }
    }
}
