package com.tensuramod.command;

import com.tensuramod.capability.TensuraCapability;
import com.tensuramod.capability.TensuraData;
import com.tensuramod.core.Race;
import com.tensuramod.core.Scale;
import com.tensuramod.item.ModItems;
import com.tensuramod.network.NetworkHandler;
import com.tensuramod.skill.Core;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CommandTensura extends CommandBase {
    @Override
    public String getName() {
        return "tensura";
    }

    @Override
    public String getUsage(ICommandSender s) {
        return "/tensura <status|race <raca>|unique <nucleo>|use|fn|cast|grade|pc <n>|give>";
    }

    @Override
    public int getRequiredPermissionLevel() {
        return 0;
    }

    private void say(ICommandSender s, String t) {
        s.sendMessage(new TextComponentString(t));
    }

    @Override
    public void execute(MinecraftServer server, ICommandSender sender, String[] a) throws CommandException {
        EntityPlayerMP p = getCommandSenderAsPlayer(sender);
        TensuraData d = TensuraCapability.get(p);
        if (d == null) return;
        String sub = a.length == 0 ? "status" : a[0].toLowerCase();
        switch (sub) {
            case "status": {
                say(p, TextFormatting.GOLD + "== Tensura ==");
                say(p, "Raça: " + d.race.display + " > " + d.stageInfo().name + (d.mature() ? " (Maturidade)" : ""));
                say(p, "EP: " + (long) d.ep() + " | Rank " + Scale.rank(d.ep()) + " | E x" + String.format("%.2f", d.e()));
                say(p, "PC: " + String.format("%.1f", d.pc) + "/95 | Pool: " + (long) d.pool + "/" + (long) d.maxPool());
                say(p, "Unique: " + (d.core == null ? "nenhuma" : d.core.display + " - " + d.core.desc));
                if (d.race.hasNext(d.stage)) say(p, "Próxima evolução: " + d.race.stage(d.stage + 1).name + " (PC 70 + Pedra de Evolução)");
                break;
            }
            case "race": {
                Race r = a.length > 1 ? Race.byName(a[1]) : null;
                if (r == null) {
                    say(p, "Raças: " + Arrays.toString(Race.values()));
                    return;
                }
                d.setRace(r);
                say(p, TextFormatting.GREEN + "Você renasceu como " + r.display + ".");
                break;
            }
            case "unique": {
                Core c = a.length > 1 ? Core.byName(a[1]) : null;
                if (c == null) {
                    say(p, "Núcleos: " + Arrays.toString(Core.values()));
                    return;
                }
                d.core = c;
                say(p, TextFormatting.LIGHT_PURPLE + "Skill Unique: " + c.display + " (5 Funções liberadas).");
                break;
            }
            case "use": com.tensuramod.skill.SkillExecutor.useFunction(p, d); break;
            case "cast": com.tensuramod.skill.SkillExecutor.cast(p, d); break;
            case "fn": {
                d.selFunction = d.selFunction.next();
                say(p, "Função: " + d.selFunction.display);
                break;
            }
            case "grade": {
                d.selSpell = d.selSpell.next();
                say(p, "Magia Grau " + d.selSpell.name() + " (custo " + d.selSpell.cost + ")");
                break;
            }
            case "pc": {
                if (!sender.canUseCommand(2, "tensura")) throw new CommandException("Apenas operadores.");
                double v = a.length > 1 ? parseDouble(a[1], 0, 95) : 0;
                d.pc = v;
                say(p, "PC = " + v);
                break;
            }
            case "give": {
                if (!sender.canUseCommand(2, "tensura")) throw new CommandException("Apenas operadores.");
                p.addItemStackToInventory(new ItemStack(ModItems.NAME_SCROLL, 4));
                p.addItemStackToInventory(new ItemStack(ModItems.EVOLUTION_STONE, 2));
                break;
            }
            default:
                say(p, getUsage(sender));
        }
        NetworkHandler.sync(p);
    }

    @Override
    public List<String> getTabCompletions(MinecraftServer srv, ICommandSender s, String[] a, BlockPos pos) {
        if (a.length == 1) return getListOfStringsMatchingLastWord(a, "status", "race", "unique", "use", "fn", "cast", "grade", "pc", "give");
        List<String> l = new ArrayList<>();
        if (a.length == 2 && a[0].equalsIgnoreCase("race")) for (Race r : Race.values()) l.add(r.name().toLowerCase());
        if (a.length == 2 && a[0].equalsIgnoreCase("unique")) for (Core c : Core.values()) l.add(c.name().toLowerCase());
        return getListOfStringsMatchingLastWord(a, l);
    }
}
