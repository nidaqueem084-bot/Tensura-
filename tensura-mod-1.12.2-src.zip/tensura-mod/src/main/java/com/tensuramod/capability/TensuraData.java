package com.tensuramod.capability;

import com.tensuramod.core.Race;
import com.tensuramod.core.Scale;
import com.tensuramod.skill.Core;
import com.tensuramod.skill.FunctionType;
import com.tensuramod.skill.Spell;
import net.minecraft.nbt.NBTTagCompound;

public class TensuraData {
    public Race race = Race.HUMAN;
    public int stage = 0;
    public double pc = 0;
    public double pool = -1;
    public Core core = null;
    public FunctionType selFunction = FunctionType.STRIKE;
    public Spell selSpell = Spell.I;
    public int cooldown = 0;

    public Race.Stage stageInfo() {
        return race.stage(stage);
    }

    public double ep() {
        Race.Stage s = stageInfo();
        return Scale.ep(s.piso, s.teto, pc);
    }

    public double e() {
        return Scale.e(ep());
    }

    /** Atributos derivados: crescem com o estágio e com o PC. */
    public int attr() {
        return 10 + stage * 3 + (int) (pc / 12.0);
    }

    public double maxPool() {
        double base = Scale.pool(attr(), attr(), attr());
        double mult = 1.0;
        for (int i = 1; i <= stage; i++) {
            mult *= Math.max(1.0, Scale.evoMult(race.stage(i).piso, 1000)) * 1.4;
        }
        return base * mult;
    }

    public boolean mature() {
        return pc >= 70;
    }

    public boolean canEvolve() {
        return mature() && race.hasNext(stage);
    }

    public void evolve() {
        stage++;
        pc = 10;
        pool = maxPool();
    }

    public void setRace(Race r) {
        race = r;
        stage = 0;
        pc = 0;
        pool = maxPool();
    }

    public void addPc(double v) {
        pc = Math.max(0, Math.min(95, pc + v));
    }

    public NBTTagCompound write() {
        NBTTagCompound t = new NBTTagCompound();
        t.setString("race", race.name());
        t.setInteger("stage", stage);
        t.setDouble("pc", pc);
        t.setDouble("pool", pool);
        t.setString("core", core == null ? "" : core.name());
        t.setInteger("fn", selFunction.ordinal());
        t.setInteger("sp", selSpell.ordinal());
        return t;
    }

    public void read(NBTTagCompound t) {
        Race r = Race.byName(t.getString("race"));
        race = r == null ? Race.HUMAN : r;
        stage = Math.min(t.getInteger("stage"), race.stages.length - 1);
        pc = t.getDouble("pc");
        pool = t.hasKey("pool") ? t.getDouble("pool") : -1;
        core = Core.byName(t.getString("core"));
        selFunction = FunctionType.values()[Math.max(0, Math.min(4, t.getInteger("fn")))];
        selSpell = Spell.values()[Math.max(0, Math.min(4, t.getInteger("sp")))];
        if (pool < 0) pool = maxPool();
    }
}
