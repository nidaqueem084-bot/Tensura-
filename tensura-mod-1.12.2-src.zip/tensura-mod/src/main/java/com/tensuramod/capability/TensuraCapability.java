package com.tensuramod.capability;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTBase;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumFacing;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityInject;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.ICapabilitySerializable;

public class TensuraCapability {
    @CapabilityInject(TensuraData.class)
    public static Capability<TensuraData> CAP = null;

    public static void register() {
        CapabilityManager.INSTANCE.register(TensuraData.class, new Capability.IStorage<TensuraData>() {
            @Override
            public NBTBase writeNBT(Capability<TensuraData> c, TensuraData i, EnumFacing s) {
                return i.write();
            }

            @Override
            public void readNBT(Capability<TensuraData> c, TensuraData i, EnumFacing s, NBTBase n) {
                if (n instanceof NBTTagCompound) i.read((NBTTagCompound) n);
            }
        }, TensuraData::new);
    }

    public static TensuraData get(EntityPlayer p) {
        return p.getCapability(CAP, null);
    }

    public static class Provider implements ICapabilitySerializable<NBTTagCompound> {
        private final TensuraData data = new TensuraData();

        @Override
        public boolean hasCapability(Capability<?> c, EnumFacing f) {
            return c == CAP;
        }

        @Override
        public <T> T getCapability(Capability<T> c, EnumFacing f) {
            return c == CAP ? CAP.cast(data) : null;
        }

        @Override
        public NBTTagCompound serializeNBT() {
            return data.write();
        }

        @Override
        public void deserializeNBT(NBTTagCompound n) {
            data.read(n);
        }
    }
}
